$ErrorActionPreference="Stop"
Set-Location "$PSScriptRoot\..\backend"
if (!(Test-Path ".venv")) { py -3.11 -m venv .venv }
& ".\.venv\Scripts\python.exe" -m pip install -r requirements.txt
& ".\.venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8765
