import React from 'react';import{createRoot}from'react-dom/client';import{FluentProvider,webLightTheme}from'@fluentui/react-components';import{QueryClient,QueryClientProvider}from'@tanstack/react-query';import App from'./App';import'./styles.css';
const qc=new QueryClient({defaultOptions:{queries:{refetchInterval:6000,retry:1}}});
createRoot(document.getElementById('root')!).render(<React.StrictMode><FluentProvider theme={webLightTheme}><QueryClientProvider client={qc}><App/></QueryClientProvider></FluentProvider></React.StrictMode>);
