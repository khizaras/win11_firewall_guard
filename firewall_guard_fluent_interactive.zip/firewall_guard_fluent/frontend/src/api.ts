const BASE = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8765';
const TOKEN = import.meta.env.VITE_API_TOKEN || 'dev-token-change-me';
async function get<T>(path: string, init: RequestInit = {}): Promise<T> {
  const r = await fetch(BASE + path, { ...init, headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${TOKEN}`, ...init.headers } });
  if (!r.ok) { let m = `Request failed: ${r.status}`; try { m = (await r.json()).detail || m; } catch {} throw Error(m); }
  return r.json();
}
export type Proc = { pid: number; process: string; program_path: string; username: string; status: string; services: string[]; cpu_percent?: number; memory_bytes?: number };
export const api = {
  overview: () => get<any>('/api/overview'), processes: () => get<Proc[]>('/api/processes'), services: () => get<any[]>('/api/services'),
  metrics: () => get<any>('/api/metrics'), connections: () => get<any[]>('/api/connections'), policies: () => get<any[]>('/api/policies'),
  rules: () => get<any[]>('/api/rules'), events: () => get<any[]>('/api/events?limit=150'), activity: () => get<any[]>('/api/activity'),
  create: (target: any) => get<any>('/api/rules', { method: 'POST', body: JSON.stringify({ target }) }),
  remove: (name: string) => get<any>('/api/rules/' + encodeURIComponent(name), { method: 'DELETE' }),
  dry: (enabled: boolean) => get<any>('/api/dry-run', { method: 'POST', body: JSON.stringify({ enabled }) })
};
