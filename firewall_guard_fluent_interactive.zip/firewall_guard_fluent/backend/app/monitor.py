"""Windows process, service, network, CPU and disk telemetry."""
import os
import time
import psutil

_io_previous = None
_io_previous_at = None
_proc_io_previous = {}
_proc_io_previous_at = None


def services_by_pid():
    out = {}
    if not hasattr(psutil, "win_service_iter"):
        return out
    try:
        for s in psutil.win_service_iter():
            try:
                d = s.as_dict()
                pid = int(d.get("pid") or 0)
                if pid:
                    out.setdefault(pid, []).append(str(d.get("name") or ""))
            except (psutil.Error, OSError, ValueError):
                pass
    except (psutil.Error, OSError):
        pass
    return out


def services():
    out = []
    if not hasattr(psutil, "win_service_iter"):
        return out
    try:
        for s in psutil.win_service_iter():
            try:
                d = s.as_dict()
                out.append({
                    "name": str(d.get("name") or ""),
                    "display_name": str(d.get("display_name") or d.get("name") or ""),
                    "status": str(d.get("status") or "unknown"),
                    "pid": int(d.get("pid") or 0),
                    "start_type": str(d.get("start_type") or "unknown"),
                    "username": str(d.get("username") or ""),
                    "binpath": str(d.get("binary_path") or d.get("binpath") or ""),
                })
            except (psutil.Error, OSError, ValueError):
                pass
    except (psutil.Error, OSError):
        pass
    return sorted(out, key=lambda x: (x["display_name"].casefold(), x["name"].casefold()))


def processes():
    sm = services_by_pid()
    out = []
    for proc in psutil.process_iter(["pid", "name", "exe", "username", "status", "memory_info"]):
        try:
            d = proc.info
            pid = int(d.get("pid") or 0)
            mem = d.get("memory_info")
            try:
                cpu = proc.cpu_percent(interval=None)
            except (psutil.Error, OSError):
                cpu = 0.0
            out.append({
                "pid": pid, "process": d.get("name") or "", "program_path": d.get("exe") or "",
                "username": d.get("username") or "", "status": d.get("status") or "",
                "services": sm.get(pid, []), "cpu_percent": round(float(cpu), 1),
                "memory_bytes": int(mem.rss) if mem else 0,
            })
        except (psutil.Error, OSError):
            pass
    return sorted(out, key=lambda x: (x["process"].casefold(), x["pid"]))


def connections():
    sm = services_by_pid()
    out = []
    try:
        cons = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, OSError):
        cons = []
    for c in cons:
        if not c.raddr:
            continue
        pid = c.pid or 0
        name = "Unknown / access denied"
        exe = ""
        user = ""
        if pid:
            try:
                p = psutil.Process(pid)
                name = p.name(); exe = p.exe() or ""; user = p.username() or ""
            except (psutil.Error, OSError):
                pass
        proto = "TCP" if c.type == 1 else "UDP" if c.type == 2 else "Other"
        out.append({"pid": pid, "process": name, "program_path": exe, "username": user,
                    "services": sm.get(pid, []) if pid else [], "protocol": proto,
                    "local_address": f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "",
                    "remote_ip": c.raddr.ip, "remote_port": c.raddr.port,
                    "remote_address": f"{c.raddr.ip}:{c.raddr.port}",
                    "state": getattr(c, "status", "") or "N/A", "direction": "outbound"})
    return sorted(out, key=lambda x: (x["process"].casefold(), x["remote_address"]))


def metrics():
    """Return sampled system and per-process CPU/disk counters. First sample rates are zero."""
    global _io_previous, _io_previous_at, _proc_io_previous, _proc_io_previous_at
    now = time.monotonic()
    cpu = psutil.cpu_percent(interval=None)
    mem = psutil.virtual_memory()
    disk_rows = []
    for part in psutil.disk_partitions(all=False):
        try:
            usage = psutil.disk_usage(part.mountpoint)
            disk_rows.append({"device": part.device, "mountpoint": part.mountpoint, "filesystem": part.fstype,
                              "total_bytes": usage.total, "used_bytes": usage.used, "free_bytes": usage.free,
                              "percent": usage.percent})
        except (PermissionError, OSError):
            continue
    io = psutil.disk_io_counters(perdisk=False)
    read_rate = write_rate = 0.0
    if io and _io_previous and _io_previous_at and now > _io_previous_at:
        dt = now - _io_previous_at
        read_rate = max(0, io.read_bytes - _io_previous.read_bytes) / dt
        write_rate = max(0, io.write_bytes - _io_previous.write_bytes) / dt
    if io:
        _io_previous, _io_previous_at = io, now
    procs = []
    current_io = {}
    for p in psutil.process_iter(["pid", "name", "memory_info"]):
        try:
            d = p.info
            pid = int(d.get("pid") or 0)
            meminfo = d.get("memory_info")
            try: pct = float(p.cpu_percent(interval=None))
            except (psutil.Error, OSError): pct = 0.0
            read_b = write_b = 0
            try:
                io_c = p.io_counters()
                read_b, write_b = int(io_c.read_bytes), int(io_c.write_bytes)
                current_io[pid] = (read_b, write_b)
            except (psutil.Error, OSError, AttributeError):
                pass
            old = _proc_io_previous.get(pid)
            dt = now - _proc_io_previous_at if _proc_io_previous_at and now > _proc_io_previous_at else 0
            rps = max(0, read_b-old[0])/dt if old and dt else 0
            wps = max(0, write_b-old[1])/dt if old and dt else 0
            procs.append({"pid": pid, "process": d.get("name") or "", "cpu_percent": round(pct, 1),
                          "memory_bytes": int(meminfo.rss) if meminfo else 0,
                          "read_bytes_per_sec": round(rps), "write_bytes_per_sec": round(wps),
                          "read_bytes_total": read_b, "write_bytes_total": write_b})
        except (psutil.Error, OSError):
            pass
    _proc_io_previous, _proc_io_previous_at = current_io, now
    return {"sampled_at": time.time(), "cpu_percent": round(float(cpu), 1),
            "cpu_count_logical": psutil.cpu_count(logical=True) or 0,
            "memory_total_bytes": mem.total, "memory_available_bytes": mem.available,
            "memory_percent": mem.percent, "disk_read_bytes_per_sec": round(read_rate),
            "disk_write_bytes_per_sec": round(write_rate), "disks": disk_rows,
            "top_cpu": sorted(procs, key=lambda x: x["cpu_percent"], reverse=True)[:20],
            "top_disk": sorted(procs, key=lambda x: x["read_bytes_per_sec"]+x["write_bytes_per_sec"], reverse=True)[:20]}
