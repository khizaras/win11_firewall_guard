import json,secrets,sys,subprocess
from pathlib import Path
from fastapi import FastAPI,Header,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel,Field
from .monitor import processes,connections,services,metrics
from .firewall import create_rule,remove_rule,validate_target,inspect_rule
from .store import Store
BASE=Path(__file__).resolve().parents[1]
CONFIG_PATH=BASE/"config"/"settings.json"
def read_json(name,default):
 try:return json.loads((BASE/"config"/name).read_text(encoding="utf-8"))
 except (OSError,json.JSONDecodeError):return default
CFG=read_json("settings.json",{"dry_run":True,"api_token":"dev-token-change-me","database_path":"data/firewall_guard.db"})
DB=Store((BASE/CFG.get("database_path","data/firewall_guard.db")).resolve())
app=FastAPI(title="Firewall Guard Fluent API",version="1.0")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],allow_methods=["GET","POST","DELETE"],allow_headers=["Authorization","Content-Type"])
class RuleRequest(BaseModel):
 target:dict
 reason:str=Field(default="manual",max_length=200)
class DryRequest(BaseModel): enabled:bool
def auth(value):
 if not secrets.compare_digest(value or "","Bearer "+str(CFG.get("api_token",""))):raise HTTPException(401,"Invalid local API token")
@app.get("/api/health")
def health():return {"status":"ok","dry_run":CFG.get("dry_run",False),"platform":sys.platform}
@app.get("/api/overview")
def overview(authorization:str|None=Header(default=None)):
 auth(authorization);p=processes();c=connections();pol=read_json("policies.json",{"policies":[]}).get("policies",[])
 return {"process_count":len(p),"connection_count":len(c),"enabled_policies":sum(bool(x.get("enabled")) for x in pol),"managed_rules":sum(x["status"]=="created" for x in DB.rules()),"dry_run":CFG.get("dry_run",True)}
@app.get("/api/processes")
def get_processes(authorization:str|None=Header(default=None)):auth(authorization);return processes()
@app.get("/api/services")
def get_services(authorization:str|None=Header(default=None)):auth(authorization);return services()
@app.get("/api/metrics")
def get_metrics(authorization:str|None=Header(default=None)):auth(authorization);return metrics()
@app.get("/api/connections")
def get_connections(authorization:str|None=Header(default=None)):auth(authorization);return connections()
@app.get("/api/policies")
def get_policies(authorization:str|None=Header(default=None)):
 auth(authorization);return read_json("policies.json",{"policies":[]}).get("policies",[])
@app.get("/api/rules")
def get_rules(authorization:str|None=Header(default=None)):auth(authorization);return DB.rules()
@app.get("/api/activity")
def get_activity(authorization:str|None=Header(default=None)):auth(authorization);return DB.activity(200)
@app.get("/api/events")
def get_events(authorization:str|None=Header(default=None),limit:int=100):
 auth(authorization)
 if sys.platform!="win32":return []
 limit=max(1,min(limit,250));ids="2004,2005,2006,5152,5156,5157"
 script=("$ids=@("+ids+");$logs=@('Microsoft-Windows-Windows Firewall With Advanced Security/Firewall','Security');"+
 "$all=foreach($log in $logs){try{Get-WinEvent -FilterHashtable @{LogName=$log;Id=$ids} -MaxEvents "+str(limit)+" -ErrorAction Stop | Select-Object TimeCreated,Id,ProviderName,LevelDisplayName,Message}catch{}};"+
 "$all|Sort-Object TimeCreated -Descending|Select-Object -First "+str(limit)+"|ConvertTo-Json -Depth 3 -Compress")
 try:
  r=subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-Command",script],capture_output=True,text=True,timeout=15,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
  if r.returncode or not r.stdout.strip():return []
  data=json.loads(r.stdout);data=[data] if isinstance(data,dict) else data
  return [{"time":str(x.get("TimeCreated","")),"event_id":str(x.get("Id","")),"provider":str(x.get("ProviderName","")),"level":str(x.get("LevelDisplayName","")),"message":str(x.get("Message",""))[:2500]} for x in data if isinstance(x,dict)]
 except Exception:return []
@app.post("/api/rules")
def post_rule(req:RuleRequest,authorization:str|None=Header(default=None)):
 auth(authorization)
 try:t=validate_target(req.target)
 except (ValueError,TypeError) as e:raise HTTPException(400,str(e))
 if CFG.get("dry_run",False):
  DB.log("dry_run","Would create block rule",json.dumps(t));return {"status":"dry_run","target":t}
 try:
  name=create_rule(t);DB.add_rule("manual",name,json.dumps(t));DB.log("firewall_rule","Rule created and verified",name+" "+json.dumps(t));return {"status":"created_verified","name":name,"target":t,"verified":True}
 except Exception as e:DB.log("firewall_error","Rule creation failed",str(e));raise HTTPException(500,str(e))
@app.delete("/api/rules/{name}")
def delete_rule(name:str,authorization:str|None=Header(default=None)):
 auth(authorization)
 try:remove_rule(name);DB.set_status(name,"removed");DB.log("firewall_rule","Rule removed and verified",name);return {"status":"removed_verified","verified":True}
 except Exception as e:raise HTTPException(400,str(e))
@app.get("/api/settings")
def get_settings(authorization:str|None=Header(default=None)):
 auth(authorization);return {"dry_run":bool(CFG.get("dry_run",False)),"live_enforcement":not bool(CFG.get("dry_run",False)),"poll_interval_seconds":int(CFG.get("poll_interval_seconds",3))}
@app.post("/api/dry-run")
def dry_run(req:DryRequest,authorization:str|None=Header(default=None)):
 auth(authorization)
 CFG["dry_run"]=req.enabled
 CONFIG_PATH.write_text(json.dumps(CFG,indent=2)+"\n",encoding="utf-8")
 DB.log("settings","Dry-run changed","enabled" if req.enabled else "disabled; live enforcement enabled")
 return {"dry_run":CFG["dry_run"],"live_enforcement":not CFG["dry_run"]}
@app.get("/api/rules/{name}/verify")
def verify_rule(name:str,authorization:str|None=Header(default=None)):
 auth(authorization)
 try:return inspect_rule(name)
 except Exception as e:raise HTTPException(400,str(e))
