import sqlite3
from pathlib import Path
from datetime import datetime,timezone
class Store:
 def __init__(self,path):
  self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
  with self.db() as c:
   c.execute("CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY,ts TEXT,category TEXT,summary TEXT,details TEXT)")
   c.execute("CREATE TABLE IF NOT EXISTS rules(id INTEGER PRIMARY KEY,ts TEXT,policy_id TEXT,name TEXT UNIQUE,target TEXT,status TEXT)")
 def db(self):
  c=sqlite3.connect(self.path,timeout=5);c.execute("PRAGMA journal_mode=WAL");return c
 def log(self,cat,summary,details=""):
  with self.db() as c:c.execute("INSERT INTO activity(ts,category,summary,details) VALUES(?,?,?,?)",(datetime.now(timezone.utc).isoformat(),cat,summary,details))
 def add_rule(self,policy,name,target,status="created"):
  with self.db() as c:c.execute("INSERT OR IGNORE INTO rules(ts,policy_id,name,target,status) VALUES(?,?,?,?,?)",(datetime.now(timezone.utc).isoformat(),policy,name,target,status))
 def rules(self):
  with self.db() as c:return [dict(created=a,policy_id=b,name=n,target=t,status=s) for a,b,n,t,s in c.execute("SELECT ts,policy_id,name,target,status FROM rules ORDER BY id DESC")]
 def activity(self,limit=100):
  with self.db() as c:return [dict(time=a,category=b,summary=s,details=d) for a,b,s,d in c.execute("SELECT ts,category,summary,details FROM activity ORDER BY id DESC LIMIT ?",(limit,))]
 def set_status(self,name,status):
  with self.db() as c:c.execute("UPDATE rules SET status=? WHERE name=?",(status,name))
