# Firewall Guard Fluent — Windows 11

A local-first Windows security console with a Fluent UI-inspired React interface and a Python API. The primary workflow is **outbound block/unblock for Windows services, executable paths, and remote IP addresses**, with CPU/disk telemetry and active connection visibility.

## Features

- **Windows services:** search all visible services by service name, display name, account, status, PID, and binary command; create outbound block rules using the Windows service short name.
- **Processes:** wildcard search (`*`, `?`) across process name, PID, path, account, and service associations; create executable-scoped outbound block rules.
- **Network connections:** active remote IPs and ports, protocol, state, process and service associations; block a remote IP.
- **System monitor:** CPU and memory usage, volume capacity/free space, system-wide disk read/write throughput, and top processes by CPU/disk I/O. Telemetry refreshes every three seconds while the monitor/overview is open.
- **Managed rules:** remove app-owned rules to unblock their target where no other firewall rule blocks it.
- **Firewall events:** view relevant Windows Firewall and Filtering Platform events when the logs are available.
- **Accessible UI:** keyboard-focus-visible navigation, labels, responsive layout, Fluent UI React v9 controls, confirmation dialogs, status badges, and clear dry-run/live mode.
- **Audit history:** local SQLite log of actions and outcomes.

## Important behavior

- **Dry-run is enabled by default.** It does not change Windows Firewall. Switch it off in Overview to allow live changes.
- Live rule creation/removal invokes Windows PowerShell with UAC elevation and verifies the rule operation. Approve the UAC prompt to apply it. If UAC is cancelled, the action fails rather than being reported as successful.
- A successful firewall rule does not necessarily terminate an already-established session immediately. Some services share a host process, and a service block can disrupt dependent Windows functionality.
- Removing an app-owned rule removes only that rule. Another Windows, Group Policy, VPN, endpoint-security, or third-party firewall rule can still block the traffic.
- The connection list is a point-in-time snapshot. Windows permissions can hide some PIDs or connection details. Disk I/O counters may be unavailable for protected processes.
- CPU/disk/network indicators are investigation aids, not proof that data was exfiltrated. The app does not decrypt TLS traffic or inspect file contents in transit.
- This is a local development/security utility, not a signed, hardened commercial product. Review the source and test in a controlled environment before relying on it for incident response.

## Requirements

- Windows 11
- Python 3.11 or newer
- Node.js 20 or newer
- Administrator approval for live firewall changes

## Run locally

1. Extract the ZIP.
2. In PowerShell, from the project folder, run:

   ```powershell
   .\scripts\dev-backend.ps1
   ```

3. Open a second PowerShell window in the same folder and run:

   ```powershell
   .\scripts\dev-frontend.ps1
   ```

4. Open the local Vite URL printed by the frontend script (usually `http://127.0.0.1:5173`).
5. Start in dry-run mode, inspect the exact service/process/IP, and only switch to live mode when ready to apply changes.

The scripts create/use a Python virtual environment and install frontend dependencies. An internet connection may be required on first setup to download packages.

## Security configuration

- The default local API token in `backend/config/settings.json` is a development token. Change it before use outside a disposable local test environment and set the same token in `frontend/.env` as `VITE_API_TOKEN`.
- Keep the API bound to loopback. Do not expose it to a LAN or the public internet.
- Treat firewall policy changes as privileged actions. Only app-owned rules with the `FGF-` prefix can be removed from this app.

## Validation status

Backend unit tests cover target validation and wildcard policy matching. The package has not been validated against every Windows service, Windows edition, Group Policy configuration, endpoint-security product, or live network stack. Frontend dependency installation/build could not be verified in the generation environment; run the provided setup scripts on the target Windows 11 machine before use.
